import java.awt.Canvas;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;

import java.awt.Graphics;

/** * @author SORINAS Vincent */
/* C'est la fenetre qui va contenir tout ce qui concerne la fenetre de jeu
 * � savoir, les rectangles "les raquettes" et la balle.
 */
public class CanvasDeJeu extends Canvas implements ItfDessin
{	
	int P1;
	int P2 = 0 ;
	Toolkit tk = Toolkit.getDefaultToolkit();
	Image une = tk.getImage("URL");

	/**
	 * 
	 * @uml.property name="r1"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	/* "Pointeur" sur le canvas de jeu courant*/
	Raquette r1 = new Raquette(20); //initialise les raquettes.Malheuresement pas tr�s ind�pendant de la balle puisqu'on ne peut en mettre plus de deux sans modifier la balle

	/**
	 * 
	 * @uml.property name="r2"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	Raquette r2 = new Raquette(470);

	/*
	 * Dessine les objets appar�ssant sur le canvas
	 *  
	 */
	public void draw(Graphics g) 
	{	
		
		g.setColor(Color.red);
		g.fillOval(Balle.X,Balle.Y,Balle.tailX,Balle.tailY);
		g.setColor(Color.blue);
		g.fill3DRect(r1.X,Raquette.Y,Raquette.posX,Raquette.posY,false);
		g.setColor(Color.blue);
		g.fill3DRect(r2.X,Raquette.Y,Raquette.posX,Raquette.posY,false);
		//g.drawImage(tk.getImage("BARQUE.JPG"), 50, 50, 50,50, this); 
		
		
	}
		
	/*
	 * Initialisation du canvas .
	 */
 	CanvasDeJeu()
	{	
 		this.setSize(500,500);
 		
 		this.setBackground(Color.ORANGE);
 		new Balle();
		Balle.contexte = this;
		Raquette.Contexte = this;
	
	}
 	//Methode paint appel� pour dessiner le graph ds draw
 	public void paint (Graphics g)
 	{
 		draw(g);
 		
 	}

	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * @uml.associationEnd inverse="canvasDeJeu:FenetrePrincipale" multiplicity="(0 1)"
	 * 
	 */
	private FenetrePrincipale fenetrePrincipale;

	/**
	 *  
	 * @uml.property name="balle"
	 * @uml.associationEnd aggregation="composite" inverse="canvasDeJeu:Balle" multiplicity="(1 1)"
	 * 
	 */
	private Balle balle;

	/**
	 *  
	 * @uml.property name="raquette"
	 * @uml.associationEnd aggregation="composite" inverse="canvasDeJeu:Raquette" multiplicity="(2 2)" dimension="1" ordering="ordered"
	 * 
	 */
	private Raquette[] raquette;



	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * 
	 */
	public FenetrePrincipale getFenetrePrincipale() {
		return fenetrePrincipale;
	}

	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * 
	 */
	public void setFenetrePrincipale(FenetrePrincipale fenetrePrincipale) {
		this.fenetrePrincipale = fenetrePrincipale;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public Balle getBalle() {
		return balle;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public void setBalle(Balle balle) {
		this.balle = balle;
	}

	/**
	 *  
	 * @uml.property name="raquette"
	 * 
	 */
	public void setRaquette(Raquette[] raquette) {
		this.raquette = raquette;
	}

	/**
	 *  
	 * @uml.property name="raquette"
	 * 
	 */
	public Raquette[] getRaquette() {
		return raquette;
	}

}