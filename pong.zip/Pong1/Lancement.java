
/*
 * Created on 2 mai 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Vincent
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Lancement {
	
	/* Cette n'existe que pour lancer le jeu */
	
	public static void main (String [] args)
	{		
		new FenetreScore();
		new FenetrePrincipale();
		new FenetreBestScore();
	}
}

	