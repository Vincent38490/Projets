
/**
 * @author Vincent
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.Graphics;

public interface ItfDessin
{
	public void draw(Graphics g);
}
