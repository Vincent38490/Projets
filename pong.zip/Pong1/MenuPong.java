

/**
 * @author Seb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.*;
import java.awt.*;

/** * La barre de menu du jeu. */
public class MenuPong extends MenuBar implements ActionListener,ItemListener
{

	
	protected static MenuPong menuBar;



	
	/** Ce sont les menus. */
	private Menu menuJeu;
	/** Ce sont les menus. */
	private Menu menuOption;

	private Item quitter;

	private CheckBox pause;

	
	private CheckBox music;

	
	/**  Les items de chaque menu */
	
	public class Item extends MenuItem
	{
		public Item(String s, char c)
		{
			super(s, new MenuShortcut(c));
			addActionListener(MenuPong.menuBar);
		}
	}
	
	public class CheckBox extends CheckboxMenuItem
	{
		
		public CheckBox(String s, boolean b, char c)
		{
			super(s, b);
			setShortcut(new MenuShortcut(c));
			addItemListener(MenuPong.menuBar);
		}
	}
	
	

	public MenuPong()
	{
		menuBar = this;
		
		// MENU JEU
		menuBar.add(menuJeu = new Menu("Jeu"));	
		menuJeu.add(pause = new CheckBox("Pause", false, 'P'));
		menuJeu.addSeparator();
		menuJeu.add(quitter = new Item("Quitter", 'Q'));
		
		// MENU OPTIONS
		menuBar.add(menuOption = new Menu("Options"));
		menuOption.add(music = new CheckBox("Music On/Off", false, 'M'));
		
		
	}
	
	
	
	  public void actionPerformed(ActionEvent e)
	  {
	
	/** Gr�ce � cette m�thode on attrape l'�v�nement, et on ex�cute l'action appropri�e. */	
	

	  	if (e.getSource() == quitter)
	  	{
	  		System.exit(0);
	  	}
	  	
	  }
	  
	  public void itemStateChanged(ItemEvent ev)
	  {
	  	if (ev.getSource() == pause)
	  	{
	  		if (pause.getState()==true)
	  		{
	  			System.out.println("Pause On");
		  		Balle.pause(); 
	  		}
	  		else System.out.println("Pause Off");
	  	}
	  	
	  	else if (ev.getSource() == music)
	  	{
	  		if (music.getState() == true)
	  			Sonpong.musiqueOn();
	  		else Sonpong.musiqueOff();
	  	}
	  }
	  
	  /**
	   * Pour r�cup�rer la barre de menu menuBar que l'on a construit on a besoin de cette m�thode.
	   * @return MenuTetris menuBar.
	   */

	  public MenuBar renvoiBar()
	  {
	  	return menuBar;
	  }

	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * @uml.associationEnd inverse="menuPong:FenetrePrincipale" multiplicity="(0 1)"
	 * 
	 */
	private FenetrePrincipale fenetrePrincipale;







	/**
	 *  
	 * @uml.property name="sonpong"
	 * @uml.associationEnd inverse="menuPong:Sonpong" multiplicity="(0 1)"
	 * 
	 */
	private Sonpong sonpong;

	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * 
	 */
	public FenetrePrincipale getFenetrePrincipale() {
		return fenetrePrincipale;
	}

	/**
	 *  
	 * @uml.property name="fenetrePrincipale"
	 * 
	 */
	public void setFenetrePrincipale(FenetrePrincipale fenetrePrincipale) {
		this.fenetrePrincipale = fenetrePrincipale;
	}

/**
	 *  
	 * @uml.property name="sonpong"
	 * 
	 */
	public Sonpong getSonpong() {
		return sonpong;
	}

	/**
	 *  
	 * @uml.property name="sonpong"
	 * 
	 */
	public void setSonpong(Sonpong sonpong) {
		this.sonpong = sonpong;
	}

}
