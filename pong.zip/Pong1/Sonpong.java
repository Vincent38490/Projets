import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;


/**
 * @author Namour
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Sonpong {

	private static File soundfile = new File("musique/son.mid");
	private static Sequence seq;
	private static Sequencer player;
	private static boolean enLecture;
	
	public static void musique()
	{
		try{
		seq = MidiSystem.getSequence(soundfile);
		player = MidiSystem.getSequencer();
		player.open();
		player.setSequence(seq);
		player.start();}catch (InvalidMidiDataException e){}
		catch(IOException e){}
		catch(MidiUnavailableException e){}
	}
	
	public static void musiqueOn()
	{
		enLecture = true;
		musique();
	}
	
	public static void musiqueOff()
	{
		enLecture = false;
		player.stop();
	}
	
	public static void sonRebond() 
	{
		try
		{
			String cheminSon = "pivot.wav";
			File f1=new File("musique//rebond.wav");
			URL url=f1.toURL();
			AudioClip son1 = Applet.newAudioClip(url);
			son1.play();
			
		}
		catch(MalformedURLException me)
		{
			System.out.println("Probleme!");
		} 
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * @uml.associationEnd inverse="sonpong:Balle" multiplicity="(0 1)"
	 * 
	 */
	private Balle balle;






	/**
	 *  
	 * @uml.property name="menuPong"
	 * @uml.associationEnd inverse="sonpong:MenuPong" multiplicity="(0 1)"
	 * 
	 */
	private MenuPong menuPong;

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public Balle getBalle() {
		return balle;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public void setBalle(Balle balle) {
		this.balle = balle;
	}

/**
	 *  
	 * @uml.property name="menuPong"
	 * 
	 */
	public MenuPong getMenuPong() {
		return menuPong;
	}

	/**
	 *  
	 * @uml.property name="menuPong"
	 * 
	 */
	public void setMenuPong(MenuPong menuPong) {
		this.menuPong = menuPong;
	}

}
