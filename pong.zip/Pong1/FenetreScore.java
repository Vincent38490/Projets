
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Panel;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;





/** * @author Vincent *  * TODO To change the template for this generated type comment go to * Window - Preferences - Java - Code Style - Code Templates */
public class FenetreScore extends Frame{
	static int P1=0;

	/**
	 * 
	 * @uml.property name="canvas"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	private CanvasDeScore canvas;

	private static boolean perdu = false;
	static void perdu()
	{
		perdu  = true;
		P1 = 0;
		}
	
	
	public void InitFenetre()
	{	
		new Compteur();
		
		new Frame();
		setTitle("Score");
		Panel ZoneJeu = new Panel();
		ZoneJeu.setBackground(Color.LIGHT_GRAY);
		
		// Point crucial !!!!!!!
		canvas = new CanvasDeScore();
		ZoneJeu.add(canvas);
		canvas.setLocation(0,0);		
		add(BorderLayout.CENTER,ZoneJeu);
	}
	FenetreScore()
	{	
		this.setSize(100,100);
		this.setResizable(false);
		InitFenetre();
		pack();
		this.setBackground(Color.LIGHT_GRAY);
		this.setLocation(50,50);
		this.setVisible(true);
		
	}
	
	WindowAdapter Win = new WindowAdapter ()
	{
		public void windowClosing (WindowEvent e)
		{
			System.exit(0);
		}
	};

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * @uml.associationEnd aggregation="aggregate" inverse="fenetreScore:CanvasDeScore" multiplicity="(0 -1)" dimension="1" ordering="ordered"
	 * 
	 */
	private CanvasDeScore[] canvasDeScore;






	/**
	 *  
	 * @uml.property name="lancement"
	 * @uml.associationEnd inverse="fenetreScore:Lancement" multiplicity="(0 1)"
	 * 
	 */
	private Lancement lancement;

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * 
	 */
	public void setCanvasDeScore(CanvasDeScore[] canvasDeScore) {
		this.canvasDeScore = canvasDeScore;
	}
/**
	 *  
	 * @uml.property name="lancement"
	 * 
	 */
	public void setLancement(Lancement lancement) {
		this.lancement = lancement;
	}

	/**
	 *  
	 * @uml.property name="lancement"
	 * 
	 */
	public Lancement getLancement() {
		return lancement;
	}

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * 
	 */
	public CanvasDeScore[] getCanvasDeScore() {
		return canvasDeScore;
	}

}
