
/**
 * @author Vincent
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FenetrePrincipale extends Frame {

	/**
	 * 
	 * @uml.property name="canvas"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	/* La premiere fenetre que l'on verra en lan�ant le jeu est la fenetre principale
	 * Ici on d�finit les m�nu et toutes les zones que contiendra la fenetre principale
	 */
	private CanvasDeJeu canvas;

	/**
	 * 
	 * @uml.property name="mb"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	private MenuPong mb = new MenuPong();

	public FenetrePrincipale ()
	{	
		/* Creation et initialisation de la fenetre */
		
		//Declaration de la fenetre
		 new Frame ();
		 
		 setTitle("Le Pong");
		 
		//Creation de la fonction qui impl�mente la fermeture de la fenetre
		WindowAdapter Win = new WindowAdapter ()
		{
			public void windowClosing (WindowEvent e)
			{
				System.exit(0);
			}
		};
			
		//On ajoute le catcheur d'�venement window listener
		this.addWindowListener(Win);
		this.setSize(500,500);
		
		this.setMenuBar(mb.renvoiBar());
		// On initialise la fenetre
		InitFenetre();
		pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.canvas.requestFocus();
		this.setResizable(false);
		}
	
	
	public void InitFenetre()
	{
		
	
		Panel ZoneJeu = new Panel();
		ZoneJeu.setBackground(Color.LIGHT_GRAY);
		
		//Cr�er le Canvas de jeu
		canvas = new CanvasDeJeu();
		ZoneJeu.add(canvas);
		canvas.setLocation(0,0);
		
		canvas.addKeyListener(new ClavierEvent());
	
		add(BorderLayout.CENTER,ZoneJeu);
		
		
	
		
	}
	
	/* 
	 * Cette m�thode sert � g�rer les touches claviers
	 * */

	
	public class ClavierEvent extends KeyAdapter
	{
				public void keyPressed(KeyEvent e)
				{
						
						if (e.getKeyCode() == KeyEvent.VK_UP)
						{
							Raquette.haut();
							canvas.repaint();
							
						}
						
						if (e.getKeyCode() == KeyEvent.VK_DOWN)
						{
							
										
										Raquette.bas();
										canvas.repaint();
										
															
						}
						
		
					
				}
		}

	/**
	 *  
	 * @uml.property name="menuPong"
	 * @uml.associationEnd aggregation="composite" inverse="fenetrePrincipale:MenuPong" multiplicity="(0 1)"
	 * 
	 */
	private MenuPong menuPong;


	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * @uml.associationEnd aggregation="composite" inverse="fenetrePrincipale:CanvasDeJeu" multiplicity="(0 -1)" dimension="1" ordering="ordered"
	 * 
	 */
	private CanvasDeJeu[] canvasDeJeu;









	/**
	 *  
	 * @uml.property name="lancement"
	 * @uml.associationEnd inverse="fenetrePrincipale:Lancement" multiplicity="(0 1)"
	 * 
	 */
	private Lancement lancement;

	/**
	 *  
	 * @uml.property name="menuPong"
	 * 
	 */
	public MenuPong getMenuPong() {
		return menuPong;
	}

	/**
	 *  
	 * @uml.property name="menuPong"
	 * 
	 */
	public void setMenuPong(MenuPong menuPong) {
		this.menuPong = menuPong;
	}

/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public CanvasDeJeu[] getCanvasDeJeu() {
		return canvasDeJeu;
	}

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public void setCanvasDeJeu(CanvasDeJeu[] canvasDeJeu) {
		this.canvasDeJeu = canvasDeJeu;
	}

/**
	 *  
	 * @uml.property name="lancement"
	 * 
	 */
	public Lancement getLancement() {
		return lancement;
	}

	/**
	 *  
	 * @uml.property name="lancement"
	 * 
	 */
	public void setLancement(Lancement lancement) {
		this.lancement = lancement;
	}

}