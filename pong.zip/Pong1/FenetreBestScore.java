import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/**
 * @author Vincent SORINAS
 *
 */
public class FenetreBestScore extends Frame{
	public void InitFenetre()
	{	
		CanvasDeBestScore canvas;
		new Frame();
		setTitle("Le meilleur Score");
		Panel ZoneJeu = new Panel();
		ZoneJeu.setBackground(Color.LIGHT_GRAY);
		
		canvas = new CanvasDeBestScore();
		ZoneJeu.add(canvas);
		canvas.setLocation(0,0);		
		add(BorderLayout.CENTER,ZoneJeu);
	}
	FenetreBestScore()
	{	
		this.setSize(100,100);
		this.setResizable(false);
		InitFenetre();
		this.setBackground(Color.LIGHT_GRAY);
		this.setLocation(850,50);
		this.setVisible(true);
		
	}
	
	WindowAdapter Win = new WindowAdapter ()
	{
		public void windowClosing (WindowEvent e)
		{
			System.exit(0);
		}
	};

}
