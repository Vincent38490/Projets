
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;




/**
 * @author Vincent
 */
/* C'est la fenetre qui va contenir tout ce qui concerne la fenetre de score
 * � savoir, un compteur.
 */
public class CanvasDeScore extends Canvas{
//initialistation du canvas couleur taille objet(thread) associer	
	CanvasDeScore()
	{	
		Compteur.contexte = this;
 		this.setSize(70,50);
 		
 		this.setBackground(Color.orange);
 		
	}
	/*
	 * Dessine les objets appar�ssant sur le canvas,
	 *  le score.
	 */
	public void draw(Graphics g) {
		Font f = g.getFont();
		g.setColor(Color.BLACK);
        g.setFont( new Font( f.getName(), Font.BOLD, 40) );
		g.drawString( ""+FenetreScore.P1, 15,40);
		System.out.println(FenetreScore.P1);
		
	}
	public void paint (Graphics g)
 	{
 		draw(g);
 	}

	/**
	 *  
	 * @uml.property name="fenetreScore"
	 * @uml.associationEnd inverse="canvasDeScore:FenetreScore" multiplicity="(0 1)"
	 * 
	 */
	private FenetreScore fenetreScore;

	/**
	 *  
	 * @uml.property name="compteur"
	 * @uml.associationEnd aggregation="composite" inverse="canvasDeScore:Compteur" multiplicity="(0 -1)" dimension="1" ordering="ordered"
	 * 
	 */
	private Compteur[] compteur;



	/**
	 *  
	 * @uml.property name="fenetreScore"
	 * 
	 */
	public FenetreScore getFenetreScore() {
		return fenetreScore;
	}

	/**
	 *  
	 * @uml.property name="fenetreScore"
	 * 
	 */
	public void setFenetreScore(FenetreScore fenetreScore) {
		this.fenetreScore = fenetreScore;
	}

	/**
	 *  
	 * @uml.property name="compteur"
	 * 
	 */
	public void setCompteur(Compteur[] compteur) {
		this.compteur = compteur;
	}

	/**
	 *  
	 * @uml.property name="compteur"
	 * 
	 */
	public Compteur[] getCompteur() {
		return compteur;
	}

}
