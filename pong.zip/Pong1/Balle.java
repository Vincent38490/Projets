
/** * @author SORINAS Vincent */
public class Balle extends Thread {


/* Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse **/
	static int X;

/*	 Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse*/
	static int Y;

/*	 Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse*/
	static int tailX;

/*	 Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse*/
	static int tailY;

/*	 Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse*/
	static int xvBalle;

/*	 Variable Repr�senter les positions de la balle sa taille 
 et sa vitesse*/
	static int yvBalle;

	/**
	 * 
	 * @uml.property name="contexte"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	static CanvasDeJeu contexte; //Le cannvas associer � la balle

	static boolean pause= true;  //Variable qui sert mettre la balle en pose
	
	/*initialisation de la balle*/
	
	Balle()
	{	yvBalle = 1;
	    xvBalle = 1; 
		X = 250;
		Y = 250 ;
		tailX = 10;
		tailY = 10;
		start();
	}

	/* 
	 * D�place la balle en modifiant ces coordon�es
	 */
	
	public void avancer ()
	{
		X = xvBalle + X;
		Y = yvBalle + Y;
	}
	
	/*
	 * Ce qui se passe quand la balle est d�marr�e
	 * On requarde si le joueur n'a pas perdu ces � dire si 
	 * la balle n'est pas sortie de la fen�tre � gauche ou � 
	 * droite il faudrait pour du vrai objet plutot que 
	 * 500 r�cup�rer la taille du canvas associ� � la balle 
	 * mais je ne sais pas faire et le temps presse.
	 * On fait rebondir la barre sur les murs haut et bas si 
	 * n�cessaire.
	 * */
	public void run() {
		while (true)
		{
			perdu();
			if ( Y > 500 || Y < 0)
			{
				yvBalle = - yvBalle;
				
				}
			if (choc())
			{	// accelere(); Pour �ventuellement acc�lerer la balle � chaque choc mais sa bug car la balle va trop vite et donc peut sortir des raquettes sans rebondir sur elle.  
				 xvBalle  = - xvBalle;
				Sonpong.sonRebond();  // A chaque choc un son
			}
			
			if(pause)  //Si il y a la pause on s'arr�te
			avancer();
		
		
		try {
			Thread.sleep(10);
		}catch (Exception e){}
		
		contexte.repaint();  //Apr�s avoir modifier les positions il faut rafraichir le canvas
		}
	}

/*
 * Acc�cl�re la balle
 * */
	
	private void accelere() {
	if(xvBalle > 0)
		xvBalle += 1 ;
		else xvBalle -= 1 ;
		
	}

	/*
	 * Compare la position de la balle et des raquettes pour constater un choc �ventuel
	 */
	private boolean choc() {
		if((Raquette.Y < Y + 10  & Raquette.Y > Y -75) & (X == 460  || X == 30 ) )
			return true;
			else
		return false;
	}
	/* 
	 * Si on perd on recentre la balle et on dit au score
	 * que ces finis, il a perdu.
	 */
	
	private void perdu()
	{
	if(X<0)
	{	
	X = 250;
	xvBalle =1;
	FenetreScore.perdu();
	}
	
	if(X>500)
	{
	X = 250;
	xvBalle = 1;
	FenetreScore.perdu();
	}
	}

	/*
	 * Mets le jeu en pause ou l'enl�ve marche pas tr�s bien
	 */
	public static void pause() {
		pause = !pause;
		}

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * @uml.associationEnd inverse="balle:CanvasDeJeu" multiplicity="(0 1)"
	 * 
	 */
	private CanvasDeJeu canvasDeJeu;


	/**
	 *  
	 * @uml.property name="sonpong"
	 * @uml.associationEnd inverse="balle:Sonpong" multiplicity="(0 1)"
	 * 
	 */
	private Sonpong sonpong;










	/**
	 *  
	 * @uml.property name="compteur"
	 * @uml.associationEnd inverse="balle:Compteur" multiplicity="(0 1)"
	 * 
	 */
	private Compteur compteur;

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public CanvasDeJeu getCanvasDeJeu() {
		return canvasDeJeu;
	}

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public void setCanvasDeJeu(CanvasDeJeu canvasDeJeu) {
		this.canvasDeJeu = canvasDeJeu;
	}

/**
	 *  
	 * @uml.property name="sonpong"
	 * 
	 */
	public Sonpong getSonpong() {
		return sonpong;
	}

	/**
	 *  
	 * @uml.property name="sonpong"
	 * 
	 */
	public void setSonpong(Sonpong sonpong) {
		this.sonpong = sonpong;
	}

/**
	 *  
	 * @uml.property name="compteur"
	 * 
	 */
	public Compteur getCompteur() {
		return compteur;
	}

	/**
	 *  
	 * @uml.property name="compteur"
	 * 
	 */
	public void setCompteur(Compteur compteur) {
		this.compteur = compteur;
	}

	/**
	 *  
	 * @uml.property name="raquette"
	 * @uml.associationEnd inverse="balle:Raquette" multiplicity="(0 -1)" dimension="1" ordering="ordered"
	 * 
	 */
	private Raquette[] raquette;

	/**
	 *  
	 * @uml.property name="raquette"
	 * 
	 */
	public Raquette[] getRaquette() {
		return raquette;
	}

	/**
	 *  
	 * @uml.property name="raquette"
	 * 
	 */
	public void setRaquette(Raquette[] raquette) {
		this.raquette = raquette;
	}

}
