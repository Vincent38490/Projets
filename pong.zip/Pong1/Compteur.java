

/** * @author Vincent Sorinas */
/*
 * Compte le temps qui passe variable P incr�menter chaque seconde
 */
public class Compteur extends Thread
{

	/**
	 * 
	 * @uml.property name="contexte"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	static CanvasDeScore contexte;
	static CanvasDeBestScore contexte2;

	Compteur()
	{
	start();
	}
	public void run() {
	while(true)
	{	
	try {
		if(Balle.pause)
		{
		FenetreScore.P1++;
		}
		Thread.sleep(1000);
		contexte.repaint();
		contexte2.repaint();
	}catch (Exception e){}
	}
	
	}

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * @uml.associationEnd inverse="compteur:CanvasDeScore" multiplicity="(0 1)"
	 * 
	 */
	private CanvasDeScore canvasDeScore;










	/**
	 *  
	 * @uml.property name="balle"
	 * @uml.associationEnd inverse="compteur:Balle" multiplicity="(0 1)"
	 * 
	 */
	private Balle balle;

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * 
	 */
	public CanvasDeScore getCanvasDeScore() {
		return canvasDeScore;
	}

	/**
	 *  
	 * @uml.property name="canvasDeScore"
	 * 
	 */
	public void setCanvasDeScore(CanvasDeScore canvasDeScore) {
		this.canvasDeScore = canvasDeScore;
	}

/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public Balle getBalle() {
		return balle;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public void setBalle(Balle balle) {
		this.balle = balle;
	}

}
