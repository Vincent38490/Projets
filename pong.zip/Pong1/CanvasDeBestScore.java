import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;


/**
 * @author Vincent SORINAS
 */


public class CanvasDeBestScore extends Canvas {
	public static int Bscore = 0;
	public static void actu(int p)
 	{
 		if(p > Bscore)
 			Bscore = p;
 	}
	CanvasDeBestScore()
	{	
		
 		this.setSize(70,50);
 		
 		this.setBackground(Color.orange);
 		
	}
	

	/*
	 * Dessine les objets appar�ssant sur le canvas,
	 *  le score.
	 */
	public void draw(Graphics g) {
		Font f = g.getFont();
		g.setColor(Color.BLACK);
        g.setFont( new Font( f.getName(), Font.BOLD, 40) );
		g.drawString( ""+Bscore, 15,40);		
		//System.out.println(FenetreScore.P1);
		
	}
	public void paint (Graphics g)
 	{
 		draw(g);
 	}
}
