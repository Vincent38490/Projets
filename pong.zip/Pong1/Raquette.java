

/** * @author Vincent *  * TODO To change the template for this generated type comment go to * Window - Preferences - Java - Code Style - Code Templates */
public class Raquette {

	/**
	 * 
	 * @uml.property name="contexte"
	 * @uml.associationEnd multiplicity="(0 1)"
	 */
	static CanvasDeJeu Contexte;

	static int Y;   //position verticale des Raquettes
	static int posX;  //taille de la raquette
	static int posY;  //taille de l'autre raquette
	int X; 				// position horizontal de la raquette
	
	//initialise une raquette
	
	Raquette (int p)
	{
		X = p;
		Y = 250;
		posX = 15;
		posY = 75;
	}
	//fait monter la raquette 
	public static void haut ()
	{	if(Y> 0)
		Y = Y - 5;
	}
//	fait descendre la raquette 
	public static void bas() {
		if(Y<425)
		Y = Y + 5;
		
	}

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * @uml.associationEnd inverse="raquette:CanvasDeJeu" multiplicity="(0 1)"
	 * 
	 */
	private CanvasDeJeu canvasDeJeu;

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public CanvasDeJeu getCanvasDeJeu() {
		return canvasDeJeu;
	}

	/**
	 *  
	 * @uml.property name="canvasDeJeu"
	 * 
	 */
	public void setCanvasDeJeu(CanvasDeJeu canvasDeJeu) {
		this.canvasDeJeu = canvasDeJeu;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * @uml.associationEnd inverse="raquette:Balle" multiplicity="(0 1)"
	 * 
	 */
	private Balle balle;

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public Balle getBalle() {
		return balle;
	}

	/**
	 *  
	 * @uml.property name="balle"
	 * 
	 */
	public void setBalle(Balle balle) {
		this.balle = balle;
	}

}
